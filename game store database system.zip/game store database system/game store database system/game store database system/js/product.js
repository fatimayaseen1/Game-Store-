// js/product.js
async function loadProductById() {
    const id = new URLSearchParams(window.location.search).get("id");
    if (!id) return;
  
    try {
      const res = await fetch(`http://localhost:3000/product/${id}`);
      if (!res.ok) throw new Error("Failed to fetch game");
  
      const game = await res.json();
      localStorage.setItem("selectedGame", JSON.stringify(game));
    } catch (err) {
      console.error("❌ Error loading product:", err);
      alert("Could not load product details.");
      window.location.href = "index.html";
    }
  }
  
  function showProductDetails() {
    const game = JSON.parse(localStorage.getItem("selectedGame"));
    if (!game) {
      alert("No product found.");
      window.location.href = "index.html";
      return;
    }
  
    document.getElementById("productImage").src = game.image.startsWith("data:")
      ? game.image
      : `data:image/png;base64,${game.image}`;
    document.getElementById("productTitle").innerText = game.title;
    document.getElementById("productDescription").innerText = game.description;
    document.getElementById("productPrice").innerText = `$${game.price}`;
  }
  
  function addingToCart() {
    console.log("Adding to cart");
    const game = JSON.parse(localStorage.getItem("selectedGame"));
    if (!game) {
      alert("Error adding to cart");
      return;
    }
  

    // Call the addToCart function from cart.js
    //why not defined here as define in index.js ?


    addToCart(game);
  }
  
  document.addEventListener("DOMContentLoaded", async () => {
    await loadProductById();
    showProductDetails();
  
    const addToCartBtn = document.getElementById("addToCartBtn");
    if (addToCartBtn) {
      addToCartBtn.addEventListener("click", addingToCart);
    }
  });
  