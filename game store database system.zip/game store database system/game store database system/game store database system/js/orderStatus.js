let currentStatus = 'pending';

async function loadOrders(status) {
  const userId = localStorage.getItem('user_id');
  if (!userId) {
    alert('You must be logged in to view orders.');
    window.location.href = 'login.html';
    return;
  }

  currentStatus = status;
  document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
  document.querySelector(`.tab:nth-child(${status === 'pending' ? 1 : 2})`).classList.add('active');

  try {
    const res = await fetch(`http://localhost:3000/orderStatus?user_id=${userId}&status=${status}`);
    const orders = await res.json();
    renderOrders(orders);
  } catch (err) {
    console.error('Error loading orders:', err);
    document.getElementById('ordersContainer').innerHTML = '<p>Error loading orders.</p>';
  }
}

function renderOrders(orders) {
  const container = document.getElementById('ordersContainer');
  container.innerHTML = '';

  if (orders.length === 0) {
    container.innerHTML = '<p>No orders found.</p>';
    return;
  }

  orders.forEach(order => {
    const card = document.createElement('div');
    card.classList.add('order-card');
    card.innerHTML = `
      <p><strong>Order ID:</strong> ${order.order_id}</p>
      <p><strong>Date:</strong> ${new Date(order.order_date).toLocaleString()}</p>
      <p><strong>Total:</strong> $${parseFloat(order.total_amount).toFixed(2)}</p>
      <p><strong>Status:</strong> ${order.status}</p>
    `;

    if (order.status === 'pending') {
      const completeBtn = document.createElement('button');
      completeBtn.innerText = 'Mark as Completed';
      completeBtn.onclick = () => markAsCompleted(order.order_id);
      card.appendChild(completeBtn);
    }

    container.appendChild(card);
  });
}

async function markAsCompleted(orderId) {
  try {
    const res = await fetch(`http://localhost:3000/orderStatus/complete/${orderId}`, {
      method: 'PUT'
    });

    const result = await res.json();
    if (result.success) {
      alert('Order marked as completed.');
      loadOrders(currentStatus);
    } else {
      alert('Failed to update order.');
    }
  } catch (err) {
    console.error('Error updating order status:', err);
    alert('An error occurred.');
  }
}

document.addEventListener('DOMContentLoaded', () => loadOrders('pending'));
