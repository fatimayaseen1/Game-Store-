function loadGames(category = "all") {
    const container = document.getElementById("gameList");
    if (!container) return;
  
    container.innerHTML = "";
  
    const filtered = category === "all" ? games : games.filter(g => g.category === category);
  
    filtered.forEach(game => {
      const card = document.createElement("div");
      card.className = "game-card";
      card.innerHTML = `
        <img src="${game.image}" alt="${game.title}" />
        <div class="game-card-content">
          <h3>${game.title}</h3>
          <p>${game.description}</p>
          <button onclick="viewDetails(${game.id})">View Details</button>
        </div>
      `;
      container.appendChild(card);
    });
  }
  
  function filterGames() {
    const category = document.getElementById("category").value;
    loadGames(category);
  }
  // Function to view game details
  // This function is called when the "View Details" button is clicked
  function viewDetails(id) {
    const game = games.find(g => g.id === id);
    if (game) {
      localStorage.removeItem("selectedGame");
      localStorage.setItem("selectedGame", JSON.stringify(game));
      window.location.href = "product.html";
    }
  }
  // Function to load product details
  //
  function showProductDetails() {
    const game = JSON.parse(localStorage.getItem("selectedGame"));
    if (!game) return;
  
    document.getElementById("productImage").src = game.image;
    document.getElementById("productTitle").innerText = game.title;
    document.getElementById("productDescription").innerText = game.description;
    document.getElementById("productPrice").innerText = `$${game.price}`;
  }
  function removeFromCart(index) {
    console.log("This run");
    const cart = JSON.parse(localStorage.getItem("cart") || "[]");
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
  }
  
  // Function to render the cart items
  // This function is called when the cart page is loaded
  function renderCart() {
    const items = JSON.parse(localStorage.getItem("cart") || "[]");
    const container = document.getElementById("cartItems");
    const totalEl = document.getElementById("totalPrice");
    if (!container || !totalEl) return;
  
    container.innerHTML = "";
    let total = 0;
  
    items.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "game-card";
      card.innerHTML = `
        <img src="${item.image}" alt="${item.title}" />
        <div class="game-card-content">
          <h3>${item.title}</h3>
          <p>$${item.price.toFixed(2)}</p>
          <button onclick="removeFromCart(${index})">Remove</button>
        </div>
      `;
      container.appendChild(card);
      total += item.price;
    });
  
    totalEl.innerText = total.toFixed(2);
  }
  // Function to confirm the order
  // This function is called when the "Confirm Order" button is clicked
  async function renderSummary() {
    const container = document.getElementById("summaryItems");
    const totalEl = document.getElementById("summaryTotal");
    if (!container || !totalEl) return;
  
    try {
      const response = await fetch('http://localhost:3000/cart');
      if (!response.ok) throw new Error("Failed to fetch cart data");
  
      const items = await response.json();
  
      container.innerHTML = "";
      let total = 0;
  
      items.forEach(item => {
        const div = document.createElement("div");
        div.innerHTML = `<p>${item.title} - $${item.price}</p>`;
        container.appendChild(div);
        total += item.price;
      });
  
      totalEl.innerText = total.toFixed(2);
    } catch (err) {
      console.error("❌ Error loading cart summary:", err);
      alert("Could not load cart summary.");
    }
  }
   // Function to confirm or cancel the order
  // This function is called when the "Confirm Order" or "Cancel Order" button is clicked
  
  document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("gameList")) loadGames();
    if (document.getElementById("productImage")) showProductDetails();
    if (document.getElementById("cartItems")) renderCart();
    if (document.getElementById("summaryItems")) renderSummary();
  });
  