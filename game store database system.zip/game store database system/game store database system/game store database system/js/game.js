// Handle Image Preview
function previewImage(event) {
    const file = event.target.files[0];
    const reader = new FileReader();
    
    reader.onload = function() {
      const imagePreview = document.getElementById('imagePreview');
      imagePreview.style.display = 'block';
      imagePreview.innerHTML = `<img src="${reader.result}" alt="Game Image" style="max-width: 100%; height: auto;">`;
    };
  
    if (file) {
      reader.readAsDataURL(file);
    }
  }
  
  // Handle Form Submission
  document.getElementById('uploadGameForm').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const gameTitle = document.getElementById('gameTitle').value;
    const gameDescription = document.getElementById('gameDescription').value;
    const gamePrice = document.getElementById('gamePrice').value;
    const gameGenre = document.getElementById('gameGenre').value;
    const gamePlatform = document.getElementById('gamePlatform').value;
    const gameImage = document.getElementById('gameImage').files[0];
  
    if (!gameTitle || !gameDescription || !gamePrice || !gameGenre || !gamePlatform || !gameImage) {
      alert("Please fill in all fields.");
      return;
    }
  
    const formData = new FormData();
    formData.append("title", gameTitle);
    formData.append("description", gameDescription);
    formData.append("price", gamePrice);
    formData.append("genre", gameGenre);
    formData.append("platform", gamePlatform);
    formData.append("image", gameImage);
  
    try {
      const response = await fetch('http://localhost:3000/api/games', {
        method: 'POST',
        body: formData,
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert("Game uploaded successfully!");
        window.location.href = 'adminHome.html';  // Redirect back to admin home
      } else {
        alert("Error uploading game: " + data.message);
      }
    } catch (error) {
      console.error('Error uploading game:', error);
      alert('Error uploading game. Please try again.');
    }
  });
  