let allGames = []; // Store all games here for later filtering

async function loadGames() {
    console.log("Loading games");

    try {
        const response = await fetch('http://localhost:3000/index/games');

        if (!response.ok) {
            throw new Error('Failed to fetch games');
        }

        const data = await response.json();
        console.log(data);

        allGames = data; // Store the full list of games

        displayGames(allGames); // Display all games initially

    } catch (err) {
        console.error('Error loading games:', err);
        document.getElementById('gameList').innerHTML = '<p>Error loading games</p>';
    }
}

function filterGames() {
    const selectedCategory = document.getElementById('category').value;
    
    // If the selected category is "all", display all games
    if (selectedCategory === 'all') {
        displayGames(allGames);
    } else {
        const filteredGames = allGames.filter(game => game.genre.toLowerCase() === selectedCategory.toLowerCase());
        displayGames(filteredGames);
    }
}

// Function to display the games
function displayGames(games) {
    const gameListElement = document.getElementById('gameList');
    gameListElement.innerHTML = ''; // Clear the list before adding filtered games

    if (games.length === 0) {
        gameListElement.innerHTML = '<p>No games found for this category.</p>';
        return;
    }

    games.forEach(game => {
        const gameCard = document.createElement('div');
        gameCard.classList.add('game-card');

        const gameImage = game.image ? 
            `<img src="data:image/jpeg;base64,${game.image}" alt="${game.title}" />` : '';

        gameCard.innerHTML = `
            ${gameImage}
            <div class="game-card-content">
                <h3>${game.title}</h3>
                <p>${game.description}</p>
                <p><strong>Genre:</strong> ${game.genre}</p>
                <p><strong>Platform:</strong> ${game.platform}</p>
                <p><strong>Price:</strong> $${game.price}</p>
              <button 
    onclick="location.href='product.html?id=${game.game_id}'">
    View Details
</button>

            </div>
        `;

        // Add event listener for "Add to Cart" button
        const addButton = gameCard.querySelector('button');
        addButton.addEventListener('click', (event) => {
            // Grab the game data
            const game = {
                id: event.target.getAttribute('data-game-id'), // Correcting the attribute name
                title: event.target.getAttribute('data-game-title'),
                price: event.target.getAttribute('data-game-price'),
                image: event.target.getAttribute('data-game-image')
            };

        });

        gameListElement.appendChild(gameCard);
    });
}

window.onload = loadGames;
