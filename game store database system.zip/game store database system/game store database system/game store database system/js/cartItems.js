// Function to load the cart items from the server
async function loadCartItems() {
    
  const userId = localStorage.getItem('user_id');

  if (!userId || userId === 'null' || userId === 'undefined') {
      console.warn('User not logged in. Redirecting to login.');
      window.location.href = 'login.html';
      return;
  }

  try {
      const response = await fetch(`http://localhost:3000/cart?user_id=${userId}`);
      const items = await response.json();

      renderCartItems(items);
      updateCartTotal(items);
  } catch (err) {
      console.error('Failed to load cart items:', err);
      document.getElementById('cartItems').innerHTML = '<p>Error loading cart items</p>';
  }
}

  
  // Function to render cart items (matching the layout from index.js)
  // Function to render cart items
  function renderCartItems(items) {
    const cartContainer = document.getElementById('cartItems');
    cartContainer.innerHTML = ''; // Clear previous content

    if (items.length === 0) {
        cartContainer.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }
    console.log("Cart items from server:", items);

    items.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('game-card');

        const gameImage = item.image ? 
            `<img src="data:image/jpeg;base64,${item.image}" alt="${item.title}" />` : '';

        cartItem.innerHTML = `
            ${gameImage}
            <div class="game-card-content">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <p><strong>Genre:</strong> ${item.genre}</p>
                <p><strong>Platform:</strong> ${item.platform}</p>
                <p><strong>Price:</strong> $${item.price.toFixed(2)}</p>
                <button onclick="removeFromCart(${item.cart_id})">Remove</button>
            </div>
        `;

        cartContainer.appendChild(cartItem);
    });
}
  
  
  // Function to update the total price of items in the cart
  function updateCartTotal(items) {
    const totalPriceElement = document.getElementById('totalPrice');
    if (!totalPriceElement) return;
  
    const total = items.reduce((sum, item) => sum + parseFloat(item.price), 0);
    totalPriceElement.innerText = total.toFixed(2);
  }
  
  // Function to remove an item from the cart
  // Function to remove an item from the cart
// Function to remove an item from the cart based on cart_id
async function removeFromCart(cartId) {
    try {
        // Perform the deletion on the backend using the unique cart_id
        await fetch(`http://localhost:3000/cart/${cartId}`, { method: 'DELETE' });

        // Update the local storage and UI
        const items = JSON.parse(localStorage.getItem('cart') || '[]');
        const updatedItems = items.filter(item => item.cart_id !== cartId); // Filter out the item with the unique cart_id

        // Update local storage
        localStorage.setItem('cart', JSON.stringify(updatedItems));

        // Reload the cart items to reflect the changes
        loadCartItems();
    } catch (err) {
        console.error('Failed to remove item:', err);
    }
}
  
  // Load the cart items when the page is loaded
  document.addEventListener('DOMContentLoaded', loadCartItems);
  function confirmOrder() {
    const total = document.getElementById('totalPrice').innerText;  // Get the total price text from the cart
    
    // Ensure total is a valid number and store it in localStorage
    localStorage.setItem('total_price', total);

    // Redirect to summary page
    window.location.href = 'summary.html';
}


