const { use } = require("../gamestore-backend/routes");

async function addToCart(game) {
    console.log("Adding game to cart:", game);
    const userId = localStorage.getItem('user_id');
    console.log("User ID:", userId);
  //I also want to check if the userId is null or undefined
    if (!userId || userId === 'null'|| userId === 'undefined') {
        alert("Please log in to add items to your cart.");
      console.log("user id is ", userId);
      window.location.href = 'login.html';
      return;
    }
    //I want to check datatyoe of userId
   if (typeof userId !== 'string') {

        console.error("User ID is not a string:", userId);
        alert("Invalid user ID. Please log in again.");
      
    }
    //convert user id to integer
    const userIdInt = parseInt(userId, 10);
    const cartData = {
        game_id: game.game_id,  // Ensure this is correct; you used `game.game_id` earlier.
        title: game.title,
        price: game.price,
        image: game.image || null,
        user_id: userIdInt // Include user ID in the cart data
       
    };
    console.log("Cart data:", cartData);

    try {
        const response = await fetch('http://localhost:3000/cart/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cartData)
        });

        // Handle non-JSON responses
        const responseText = await response.text();  // Read response as text
        const data = JSON.parse(responseText); // Parse the text as JSON

        if (response.ok) {
            console.log(data.message);
            alert(`${game.title} has been added to the cart!`);
        } else {
            console.error("Server error:", data.message);
            alert(`Error: ${data.message}`);
        }
    } catch (err) {
        console.error('Network error while adding to cart:', err);
        alert('Error adding game to cart');
    }
}
