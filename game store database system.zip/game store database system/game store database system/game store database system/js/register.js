const passwordInput = document.getElementById('password');
const usernameInput = document.getElementById('username');
const emailInput = document.getElementById('email');
const registerForm = document.getElementById('registerForm');

const hasLetter = document.getElementById('hasLetter');
const hasNumber = document.getElementById('hasNumber');
const hasSpecial = document.getElementById('hasSpecial');
const hasLength = document.getElementById('hasLength');
const errorText = document.getElementById('passwordError');
const registerBtn = document.getElementById('registerBtn');

function checkPasswordStrength(password) {
  const letter = /[a-zA-Z]/.test(password);
  const number = /[0-9]/.test(password);
  const special = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  const length = password.length >= 8;

  hasLetter.checked = letter;
  hasNumber.checked = number;
  hasSpecial.checked = special;
  hasLength.checked = length;

  return letter && number && special && length;
}

function validateForm() {
  const usernameFilled = usernameInput.value.trim() !== '';
  const emailFilled = emailInput.value.trim() !== '';
  const password = passwordInput.value;
  const strongPassword = checkPasswordStrength(password);

  errorText.style.display = strongPassword ? 'none' : 'block';
  registerBtn.disabled = !(usernameFilled && emailFilled && strongPassword);
}

passwordInput.addEventListener('input', validateForm);
usernameInput.addEventListener('input', validateForm);
emailInput.addEventListener('input', validateForm);

registerForm.addEventListener('submit', async function (e) {
  e.preventDefault();

  const username = usernameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  try {
    const response = await fetch('http://localhost:3000/api/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, email, password }),
    });

    const data = await response.json();

    if (response.ok) {
      alert('✅ Registered successfully!');
      window.location.href = 'login.html'; // redirect if success
    } else {
      alert('❌ Error: ' + (data.message || 'Unknown error occurred'));
    }
  } catch (err) {
    console.error('Network error:', err);
    alert('❌ Could not connect to server.');
  }
});
