document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert('Login successful!');
        console.log("Role is and id is",data);
        if (data.role === 'admin') {
            console.log( "Admin Logged in ")
          window.location.href = 'adminHome.html';  // Redirect for admin
        } else {
            localStorage.setItem('user_id', data.user_id);
            console.log( "User Logged in with id: ", data.user_id )
          window.location.href = 'index.html';      // Redirect for regular users
        }
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error('Error during login:', err);
      alert('An error occurred during login.');
    }
  });
  