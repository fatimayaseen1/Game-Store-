// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3000;
const { connect } = require('./db');

app.use(cors());
const orderStatusRoutes = require('./routes/orderStatus');
app.use('/orderStatus', orderStatusRoutes);

app.use('/product', require('./routes/product'));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static('public')); // Assuming 'js' is inside 'public'
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');
const indexsRoute = require('./routes/index');
const cartRoute = require('./routes/cart');  // Correct cart route
app.use('/cart', cartRoute); // Ensure /cart is mounted correctly
const orderRoutes = require('./routes/order');

app.use('/orders', orderRoutes);
app.use('/index/games', indexsRoute); // Games route
const gamesUploadRoute = require('./routes/game');
app.use('/api/games', gamesUploadRoute);
app.use('/api/login', loginRoute);
app.use('/api/register', registerRoute);
// Connect to DB and start server
connect()
  .then(() => {
    app.listen(port, () => {
      console.log(`Server is running at http://localhost:${port}`);
    });
  })
  .catch(err => {
    console.error('Failed to connect to database:', err);
  });