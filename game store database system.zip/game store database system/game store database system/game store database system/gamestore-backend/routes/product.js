// routes/product.js
const express = require('express');
const router = express.Router();
const { sql } = require('../db');

router.get('/:id', async (req, res) => {
  try {
    const gameId = req.params.id;
    const result = await new sql.Request().query(`SELECT * FROM Games WHERE game_id = ${gameId}`);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: 'Game not found' });
    }

    const game = result.recordset[0];
    game.image = game.image ? Buffer.from(game.image).toString('base64') : null;

    res.status(200).json(game);
  } catch (err) {
    console.error('❌ Error fetching game by ID:', err);
    res.status(500).json({ message: 'Error fetching game' });
  }
});

module.exports = router;
