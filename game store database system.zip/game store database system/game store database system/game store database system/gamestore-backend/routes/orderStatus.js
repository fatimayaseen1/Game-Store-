const express = require('express');
const router = express.Router();
const { sql } = require('../db');

// GET orders by status and user_id
router.get('/', async (req, res) => {
  const { user_id, status } = req.query;

  if (!user_id || !status) {
    return res.status(400).json({ message: 'Missing user_id or status' });
  }

  try {
    const request = new sql.Request();
    request.input('user_id', sql.Int, user_id);
    request.input('status', sql.VarChar, status);

    const result = await request.query(`
      SELECT * FROM Orders
      WHERE user_id = @user_id AND status = @status
      ORDER BY order_date DESC
    `);

    res.json(result.recordset);
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT to mark order as completed
router.put('/complete/:id', async (req, res) => {
  const orderId = req.params.id;

  try {
    const request = new sql.Request();
    request.input('order_id', sql.Int, orderId);

    await request.query(`
      UPDATE Orders
      SET status = 'completed'
      WHERE order_id = @order_id
    `);

    res.json({ success: true });
  } catch (err) {
    console.error('Error updating order:', err);
    res.status(500).json({ success: false, message: 'Update failed' });
  }
});

module.exports = router;
