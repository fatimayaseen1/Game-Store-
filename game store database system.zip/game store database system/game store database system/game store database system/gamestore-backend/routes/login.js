const express = require('express');
const router = express.Router();
const { sql } = require('../db');

router.post('/', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Validate email and password
    const request = new sql.Request();
    request.input('email', sql.VarChar, email);
    request.input('password', sql.VarChar, password);

    const result = await request.query(`
      SELECT * FROM Users WHERE email = @email AND password = @password
    `);

    if (result.recordset.length === 0) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // If user is found, check the role
    const user = result.recordset[0];
    // Successful login
res.status(200).json({ message: 'Login successful!', role: user.role, user_id: user.user_id });

  } catch (err) {
    console.error('❌ Login Error:', err);
    res.status(500).json({ message: err.message || 'Server error' });
  }
});

module.exports = router;
