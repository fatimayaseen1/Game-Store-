const express = require('express');
const router = express.Router();
const { sql } = require('../db');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });  // Store uploaded files in 'uploads' folder

// Handle Game Upload
router.post('/', upload.single('image'), async (req, res) => {
  const { title, description, price, genre, platform } = req.body;
  const image = req.file;

  if (!title || !description || !price || !genre || !platform || !image) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    // Read the image file
    const imageBuffer = require('fs').readFileSync(image.path);

    // Insert into database
    const request = new sql.Request();
    request.input('title', sql.VarChar, title);
    request.input('description', sql.VarChar, description);
    request.input('price', sql.Decimal, price);
    request.input('genre', sql.VarChar, genre);
    request.input('platform', sql.VarChar, platform);
    request.input('image', sql.VarBinary, imageBuffer);

    await request.query(`
      INSERT INTO Games (title, description, price, genre, platform, image)
      VALUES (@title, @description, @price, @genre, @platform, @image)
    `);

    // Remove the uploaded file after saving
    require('fs').unlinkSync(image.path);

    res.status(200).json({ message: 'Game uploaded successfully' });
  } catch (error) {
    console.error('Error uploading game:', error);
    res.status(500).json({ message: 'Error uploading game' });
  }
});

module.exports = router;
