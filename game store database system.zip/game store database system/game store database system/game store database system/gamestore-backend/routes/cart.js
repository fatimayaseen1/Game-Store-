const express = require('express');
const router = express.Router();
const { sql } = require('../db');  // Use mssql for database interaction

// Add game to cart
router.post('/add', async (req, res) => {
    const { game_id, title, price, image, user_id } = req.body;
console.log("userId is ", user_id);
    // Ensure the game data is complete
    if (!game_id || !title || !price) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    // If image is missing, send null
    const imageBuffer = image ? Buffer.from(image, 'base64') : null;

    try {
        // Create a new SQL request
        const request = new sql.Request();
        
        // Input the data for the query
        request.input('game_id', sql.Int, game_id);
        request.input('title', sql.VarChar, title);
        request.input('price', sql.Decimal, price);
        request.input('image', sql.VarBinary, imageBuffer); // Use valid buffer or null if no image
        request.input('user_id', sql.Int, parseInt(user_id)); // Ensure user_id is passed correctly

        // Perform the insert query
        await request.query(`
            INSERT INTO Cart (game_id, title, price, image, user_id)
            VALUES (@game_id, @title, @price, @image, @user_id)
        `);
        res.json({ message: 'Game added to cart' });
    } catch (err) {
        console.error('Error adding to cart:', err);
        res.status(500).json({ message: 'Failed to add game to cart', error: err.message });
    }
});
// Inside your /cart route in cart.js
router.get('/', async (req, res) => {
    const userId = req.query.user_id;

    if (!userId) {
        return res.status(400).json({ message: 'User ID is required' });
    }

    try {
        const request = new sql.Request();
        request.input('user_id', sql.Int, parseInt(userId));
            console.log("userId is ", userId);
        const result = await request.query(`
            SELECT c.cart_id, c.game_id, g.title, g.description, g.genre, g.platform, g.price, g.image
            FROM Cart c
            JOIN Games g ON c.game_id = g.game_id
            WHERE c.user_id = @user_id
        `);
        const cartItems = result.recordset.map(item => {
            if (item.image) {
                item.image = item.image.toString('base64'); // Convert Buffer to Base64
            }
            return item;
        });

        res.json(cartItems); // Send the cart items with image as Base64
    } catch (err) {
        console.error('Error fetching cart items:', err);
        res.status(500).json({ message: 'Failed to fetch cart items in get /' });
    }
});

router.delete('/:id', async (req, res) => {
    const gameId = req.params.id;

    try {
        const request = new sql.Request();
        request.input('game_id', sql.Int, gameId);
        await request.query('DELETE FROM Cart WHERE cart_id = @game_id');
        res.json({ message: 'Game removed from cart' });
    } catch (err) {
        console.error('Error removing item from cart:', err);
        res.status(500).json({ message: 'Failed to remove item from cart' });
    }
});
// Get all cart items
router.get('/cart', async (req, res) => {
    try {
      const result = await new sql.Request().query(`SELECT * FROM Cart`);
      res.status(200).json(result.recordset);
    } catch (err) {
      console.error('❌ Error fetching cart items:', err);
      res.status(500).json({ message: 'Error fetching cart items' });
    }
  });
  

module.exports = router;
