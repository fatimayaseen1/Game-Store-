const express = require('express');
const router = express.Router();
const { sql } = require('../db');  // Adjust according to your database connection

// Add a new order
router.post('/add', async (req, res) => {

  const { user_id, order_date, total_amount, status } = req.body;

  if (!user_id || !order_date || !total_amount || status === undefined) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  try {
    const request = new sql.Request();

    request.input('user_id', sql.Int, user_id);
    request.input('order_date', sql.DateTime, order_date);
    request.input('total_amount', sql.Decimal(10, 2), total_amount);
    request.input('status', sql.VarChar(50), status);
    console.log("In ordering user id ", user_id);
    // Insert into Orders table
    await request.query(`
      INSERT INTO Orders (user_id, order_date, total_amount, status)
      VALUES (@user_id, @order_date, @total_amount, @status)
    `);

    // Delete from Cart table for this user
    await request.query(`
      DELETE FROM Cart WHERE user_id = @user_id
    `);
 
    res.json({ success: true, message: 'Order placed and cart cleared successfully' });
  } catch (err) {
    console.error('Error placing order:', err);
    res.status(500).json({ success: false, message: 'Failed to place order', error: err.message });
  }
});

module.exports = router;
