const express = require('express');
const router = express.Router();
const { sql } = require('../db');

// Get all games
router.get('/', async (req, res) => {  // This will log every time the route is hit.

  try {
    const result = await new sql.Request().query('SELECT * FROM Games');

    if (result.recordset.length === 0) {
      console.log("No Game")
      return res.status(200).json({ message: 'No Game available now' });
    }

    // Convert image buffer to base64 string
    const games = result.recordset.map(game => {
      return {
        ...game,
        image: game.image ? Buffer.from(game.image).toString('base64') : null
      };
    });

    res.status(200).json(games);
  } catch (err) {
    console.error('❌ Error fetching games:', err);
    res.status(500).json({ message: 'Error fetching games' });
  }
});

module.exports = router;
