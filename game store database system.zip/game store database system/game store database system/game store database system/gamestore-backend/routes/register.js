// routes/register.js
const express = require('express');
const router = express.Router();
const { sql } = require('../db');

router.post('/', async (req, res) => {
  const { username, email, password } = req.body;
  const role = 'customer';

  try {
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Check for existing user
    const checkRequest = new sql.Request();
    checkRequest.input('email', sql.VarChar, email);
    const checkResult = await checkRequest.query('SELECT * FROM Users WHERE email = @email');

    if (checkResult.recordset.length > 0) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Insert new user
    const insertRequest = new sql.Request();
    insertRequest.input('username', sql.VarChar, username);
    insertRequest.input('email', sql.VarChar, email);
    insertRequest.input('password', sql.VarChar, password);
    insertRequest.input('role', sql.VarChar, role);
    await insertRequest.query(`
      INSERT INTO Users (username, email, password, role) 
      VALUES (@username, @email, @password, @role)
    `);

    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('❌ Registration Error:', err);
    res.status(500).json({ message: err.message || 'Server error' });
  }
});

module.exports = router;