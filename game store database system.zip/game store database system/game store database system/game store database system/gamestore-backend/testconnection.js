const sql = require('mssql');

const config = {
  server: 'DESKTOP-MVGGAAV\\SQLEXPRESS',
  database: 'dbProject',
  driver: 'tedious',
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
  connectionTimeout: 60000,
  requestTimeout: 60000,
};

async function testConnection() {
  try {
    await sql.connect(config);
    console.log('✅ Connection successful!');

    // Try running a simple query
    const result = await sql.query('SELECT 1 AS test');
    console.log('Query Result:', result);
    
    sql.close();
  } catch (err) {
    console.error('❌ Connection failed:', err);
  }
}

testConnection();
