const sql = require('mssql');

const config = {
  server: 'localhost', // or '127.0.0.1'
  port: 1433,
  database: 'dbProject',
  user: 'myuser',           // SQL login you created
  password: 'mypassword',   // Corresponding password
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};

async function connect() {
  try {
    await sql.connect(config);
    console.log('✅ Connected to SQL Server');
  } catch (err) {
    console.error('❌ Database connection failed', err);
    throw err;
  }
}

module.exports = { connect, sql };
